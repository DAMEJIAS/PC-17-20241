﻿using System;

namespace CalculadoraQuetzales
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Diego Mejia - 1044424");

            Console.Write("Ingrese un número: ");
            double cantidad = Convert.ToDouble(Console.ReadLine());

            int centavos = (int)(cantidad * 100);

            int billetes100 = centavos / 10000;
            centavos %= 10000;

            int billetes50 = centavos / 5000;
            centavos %= 5000;

            int billetes20 = centavos / 2000;
            centavos %= 2000;

            int billetes10 = centavos / 1000;
            centavos %= 1000;

            int billetes5 = centavos / 500;
            centavos %= 500;

            int monedas1 = centavos / 100;
            centavos %= 100;

            int monedas25 = centavos / 25;
            centavos %= 25;

            int monedas1Centavo = centavos;

            // Mostrar los resultados
            Console.WriteLine($"{billetes100} de Q 100");
            Console.WriteLine($"{billetes50} de Q 50");
            Console.WriteLine($"{billetes20} de Q 20");
            Console.WriteLine($"{billetes10} de Q 10");
            Console.WriteLine($"{billetes5} de Q 5");
            Console.WriteLine($"{monedas1} de Q 1");
            Console.WriteLine($"{monedas25} de 25 centavos");
        }
    }
}

