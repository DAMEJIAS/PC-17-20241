﻿using System.Data;
{
   Console.WriteLine("Calculadora de velocidad final");

double  vf, vi, a, t;

Console.WriteLine("Introduzca la velocidad inicial");
vi = Double.Parse(Console.ReadLine());

Console.WriteLine("Introduzca la aceleracion");
a = Double.Parse(Console.ReadLine());

Console.WriteLine("Introduzca el tiempo");
t = Double.Parse(Console.ReadLine());
vf = vi+(a*t);

Console.WriteLine("la velocidad final es de" + vf);

}

