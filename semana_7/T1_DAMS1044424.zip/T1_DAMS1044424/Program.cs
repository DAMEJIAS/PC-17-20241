﻿namespace T1_DAMS1044424_DiegoMejia
{
    class T1_DAMS1044424
 
    {
        static void Main(string[] args) 
        {
            Console.WriteLine("Mi segundo programa");

            string sNombre, sEdad, sCarrera, sCarne;

           Console.WriteLine(" Ingrese su nombre:");
           sNombre = Console.ReadLine();

           Console.WriteLine(" Ingrese su edad:");
            sEdad = Console.ReadLine();

           Console.WriteLine(" Ingrese su carrera:");
           sCarrera = Console.ReadLine();
      
           Console.WriteLine(" Ingrese su carnet:");
           sCarne = Console.ReadLine();          

           Console.WriteLine("Soy" + sNombre +"tengo" + sEdad + "años y estudio la carrera de" + sCarrera + "Mi número de carné es" + sCarne );
           Console.ReadKey();
        }
    }
 
}
