﻿// Diego Mejia 
//1044424
//fibbonacci 

using System;

namespace Fibonacci
{
    class semana9
    {
        static void Main(string[] args)
        {
          Console.Write("Biencvendio a la calculadora de fibonacci ");
            Console.Write("Ingrese un numero  ");
            int n = int.Parse(Console.ReadLine());

            int a = 0;
            int b = 1;
            int c;

            Console.WriteLine("Los terminos son " + n + );
            Console.Write(a + " " + b + " ");

            int count = 2;
            while (count < n)
            {
                c = a + b;
                Console.Write(c + " ");
                a = b;
                b = c;
                count++;
            }

            Console.WriteLine();
        }
    }
}

